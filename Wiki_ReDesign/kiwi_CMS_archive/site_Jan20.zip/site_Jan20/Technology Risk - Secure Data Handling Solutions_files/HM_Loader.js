/*HM_Loader.js
* by Peter Belesis. v4.2.1 020219
* Copyright (c) 2002 Peter Belesis. All Rights Reserved.
*/

   HM_DOM = (document.getElementById) ? true : false;
   HM_NS4 = (document.layers) ? true : false;
    HM_IE = (document.all) ? true : false;
   HM_IE4 = HM_IE && !HM_DOM;
   HM_Mac = (navigator.appVersion.indexOf("Mac") != -1);
  HM_IE4M = HM_IE4 && HM_Mac;

HM_IsMenu = !HM_IE4M && (HM_DOM || HM_NS4 || HM_IE4);

HM_BrowserString = HM_NS4 ? "NS4" : HM_DOM ? "DOM" : "IE4";


HM_GL_MenuWidth          = 175;
HM_GL_FontFamily         = "Arial, Verdana, sans-serif";
HM_GL_FontSize           = 8;
HM_GL_FontBold           = true;
HM_GL_FontItalic         = false;
HM_GL_FontColor          = "#e6e3de";
HM_GL_FontColorOver      = "#ffffff";
HM_GL_BGColor            = "#7399c6";
HM_GL_BGColorOver        = "#5177a4";
HM_GL_ItemPadding        = 3;

HM_GL_BorderWidth        = 1;
HM_GL_BorderColor        = "#e6e3de";
HM_GL_BorderStyle        = "solid";
HM_GL_SeparatorSize      = 1;
HM_GL_SeparatorColor     = "#e6e3de";

HM_GL_ImageSrc           = "/hiermenus/tri.gif";
HM_GL_ImageSrcLeft       = "/hiermenus/triL.gif";

HM_GL_ImageSrcOver 		 = "/hiermenus/tri.gif";
HM_GL_ImageSrcLeftOver   = "/hiermenus/triL.gif";

HM_GL_ImageSize          = 9;
HM_GL_ImageHorizSpace    = 5;
HM_GL_ImageVertSpace     = 5;

HM_GL_KeepHilite         = false;
HM_GL_ClickStart         = false;
HM_GL_ClickKill          = false;
HM_GL_ChildOverlap       = 0;
HM_GL_ChildOffset        = 0;
HM_GL_ChildPerCentOver   = null;
HM_GL_TopSecondsVisible  = .3;
HM_GL_ChildSecondsVisible = .3;
HM_GL_StatusDisplayBuild = 0;
HM_GL_StatusDisplayLink  = 1;
HM_GL_UponDisplay        = "";
HM_GL_UponHide           = HM_NS4 ? "" : "GS_showAllSelectElements();";

HM_GL_RightToLeft      = false;
HM_GL_CreateTopOnly      = HM_NS4 ? true : false;
HM_GL_ShowLinkCursor     = true;

HM_GL_ScrollEnabled = true;
HM_GL_ScrollBarHeight = 14;
HM_GL_ScrollBarColor = "#CCCCCC";
HM_GL_ScrollImgSrcTop = absolutePath + "/js/hiermenus/uparrow.gif";
HM_GL_ScrollImgSrcBot = absolutePath + "/js/hiermenus/downarrow.gif";
HM_GL_ScrollImgWidth = 9;
HM_GL_ScrollImgHeight = 5;

// GOLDMAN SACHS ADDITIONS
HM_GL_Minimum_Menu_Width = 50;
HM_GL_Scroll_Click_Required = false;
HM_GL_Item_Text_Trailing_Space = 10;
HM_GL_Menu_Delay = 500;

// USE THESE 2 VARIABLES TO POSITION MENUS OFF OF NAMESPACED IMAGES
// IMAGE NAME SHOULD BE OF THE FORM "elMenuXXX_pos", WHERE 'XXX' IS THE MENU PREFIX
GS_Position_By_Image_Offset_X = 0;
GS_Position_By_Image_Offset_Y = 22;

HM_a_TreesToBuild = [1,2,3,4,5];


// the following function is included to illustrate the improved JS expression handling of
// the left_position and top_position parameters introduced in 4.0.9
// and modified in 4.1.3 to account for IE6 standards-compliance mode
// you may delete if you have no use for it

function HM_f_CenterMenu(topmenuid) {
	var MinimumPixelLeft = 0;
	var TheMenu = HM_DOM ? document.getElementById(topmenuid) : window[topmenuid];
	var TheMenuWidth = HM_DOM ? parseInt(TheMenu.style.width) : HM_IE4 ? TheMenu.style.pixelWidth : TheMenu.clip.width;
	var TheWindowWidth = HM_IE ? (HM_DOM ? HM_IEcanvas.clientWidth : document.body.clientWidth) : window.innerWidth;
	return Math.max(parseInt((TheWindowWidth-TheMenuWidth) / 2),MinimumPixelLeft);
}

function positionNextMenu(previousmenuid) {
	var TheMenu = HM_DOM ? document.getElementById(previousmenuid) : HM_IE4 ? document.all(previousmenuid) : eval("window." + previousmenuid);
	var TheMenuHeight = HM_DOM ? parseInt(TheMenu.style.height) : HM_IE4 ? TheMenu.style.pixelHeight : TheMenu.clip.height;
	var TheMenuTop = HM_DOM ? TheMenu.yPos : HM_IE4 ? TheMenu.yPos : eval(TheMenu.tree.MenuTop);
	var idStr = previousmenuid.substring(7, previousmenuid.length);
	var idNumber = parseInt(idStr);
	//if (idNumber%2 == 1) 
	//{
		//document.all.calendar.style.top = (TheMenuHeight+TheMenuTop);
		return (TheMenuHeight+TheMenuTop);
	//}	
	//else 
	//{
	//	return ((TheMenuHeight+TheMenuTop)+16);
	//}
}

if(HM_IsMenu) {
//	document.write("<SCR" + "IPT LANGUAGE='JavaScript1.2' SRC='" + absolutePath + "/js/hiermenus/hm_arrays.js' TYPE='text/javascript'><\/SCR" + "IPT>");
	document.write("<SCR" + "IPT LANGUAGE='JavaScript1.2' SRC='" + absolutePath + "/js/hiermenus/HM_Script"+ HM_BrowserString +".js' TYPE='text/javascript'><\/SCR" + "IPT>");
}

//end

