//BEGIN: functions for clearing values of Directory / Search fields depending on which field focus is on
function focusSearchField()
{
   if (document.forms.fw_qs.query.value == "" || document.forms.fw_qs.query.value == "Search GSWeb")
   {
   	document.forms.fw_qs.query.value = ""
   } else {}
}

function blurSearchField() 
{
	if (document.forms.fw_qs.query.value != "") {} 
	else 
	{
		document.forms.fw_qs.query.value="Search GSWeb";
	}
}

var directorySearchString = "Search People";

function focusDirField()
{
	if (document.forms.gs_directory.fullname.value == "" || document.forms.gs_directory.fullname.value == "Search Directory" || document.forms.gs_directory.fullname.value == "Search People")
	{
		if (document.forms.gs_directory.fullname.value == "Search Directory")
			directorySearchString = "Search Directory";
		document.forms.gs_directory.fullname.value = "";
	 }else {}        
}

function blurDirField() 
{
    if (document.forms.gs_directory.fullname.value != "") {} 
    else
    {
    	document.forms.gs_directory.fullname.value= directorySearchString;
    }
}
//END: functions for clearing values of Directory / Search fields depending on which field focus is on

//BEGIN: generic functions for clearing values from search fields
function textClear(searchObject) {
	if (!searchObject.initialvalue) {
		searchObject.initialvalue = searchObject.value;
	}
	if (searchObject.value == "" || searchObject.value == searchObject.initialvalue) {
		searchObject.value = "";
	}
}

function textReturn (searchObject) {
	if (searchObject.value == "") {
		if (searchObject.initialvalue) {
			searchObject.value = searchObject.initialvalue;
		} else {
			alert ("no initial value to return");
		}
	}
}
//END: generic functions for clearing values from search fields

//BEGIN: rollovers for nav and image preloads
function swap(imgname, state)  
{   
	var stateStr = "";
	if (state != "off") stateStr = "-" + state;
	if (document.images) 
	{
		document[imgname].src = absolutePath + "/images/" + imgname + stateStr + ".gif";
	}
	return;
}

//END: rollovers for nav and image preloads

function submitSearch()
{
	if (document.forms.fw_qs.query.value=="Search GSWeb")
	{
		document.forms.fw_qs.query.value="";
	}
	document.forms.fw_qs.submit();
}

function submitDirectory()
{
	if (document.forms.gs_directory.fullname.value=="Search Directory" || document.forms.gs_directory.fullname.value=="Search People")
	{
		document.forms.gs_directory.fullname.value="";
	}
	document.forms.gs_directory.submit();
}
