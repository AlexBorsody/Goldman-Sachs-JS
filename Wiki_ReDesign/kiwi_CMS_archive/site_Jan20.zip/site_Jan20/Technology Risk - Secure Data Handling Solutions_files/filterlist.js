String.prototype.trim = function() {
	return this.replace(/(\s+$)|(^\s+)/g, '');
}

/* above is just a utility -- it should really come from some other library */

PullDownManager = Class.create();
PullDownManager.prototype  = {
	initialize : function() {
		this.pulldowns = [];
	},
	addPullDown : function(pulldown) {
		var element = $(pulldown);
		if (this.pulldowns.include(element)){
		} else {
			this.pulldowns.push(element);
		}
	},
	getPullDowns : function() {
		return this.pulldowns;
	},
	getById : function(id) {
		return this.pulldowns.find(function(pd) {
			return pd.name == id;
		});
	}
}

function classEvaluationDelegate (link, filters) {
	try {
		var matches = 0;
		var keys = 0;
		var selections = link.selections;
		for (var key in filters) {
			keys++;
			var filter = filters[key];
			if ((selections[key] && selections[key].include(filter)) || filter == UTIL.SHOW_ALL) 
				matches++;
		}
		if (matches == keys) 
			return true;
		else
			return false;
	} catch (e) {
		return true;
	}
}

var UTIL = {
	toSafeClassName : function(str) {
		var cleanString = str;
			cleanString = str.replace(/[\W]+/g, "");
		return cleanString;	
	},
	SHOW_ALL : "showAll"
}

LinkManager = Class.create();
LinkManager.prototype = {
	initialize : function(container) {
		this.container = $(container);
		if (!this.container) throw "Must instantiate a Link Manager with a valid container element";
		this.buckets = {};
		if(document.getElementById("A")){
			this.buckets['#'] = new Bucket('#');	
			var div = document.createElement("div");
			div.id = "#";
			Element.addClassName(div, "bucket"); 
			var anc = document.createElement("a");
			Element.addClassName(anc, "alphabetHeading"); 
			anc.name = "AMP";
			anc.href = "#top";
			anc.title = "Click to go to the top of the page.";
			anc.innerHTML = "#";		
			div.appendChild(anc);		
			$('links').insertBefore(div, document.getElementsByClassName('bucket')[0]);
			
			var letterRow = document.getElementsByClassName("alphabet");
			for(var i = 0; i < letterRow.length; i++){
				letterRow[i].parentNode.width="3%";
			}
			var dup = letterRow[0].cloneNode(true);
			dup.href = "#AMP";
			dup.innerHTML = "#";		
			var parentElement = letterRow[0].parentNode.parentNode;
			var newcol = document.createElement("td");
			newcol.width="3%";
			newcol.appendChild(dup);
			parentElement.insertBefore(newcol, letterRow[0].parentNode);
		}
		
	},
	addBucket : function(bucket) {
		if (bucket && bucket.name )
			this.buckets[bucket.name.toLowerCase()] = bucket;
	},
	getBucketKeys : function() {
		var keys = [];
		for (var key in this.getBuckets())
			keys.push(key);
		return keys;
	},
	getBuckets : function() {
		return this.buckets;
	},
	getBucket : function(key) {
		return this.getBuckets()[key.toLowerCase()];
	},
	addLink : function(link, bucketKey) {
		var bucket;
		if(link.text.charAt(0) >= '0' && link.text.charAt(0) <= '9' && document.getElementById("A")){
			bucket = this.getBucket('#');
		}else{
			for (var i = 0; i < link.text.length; i++) {
				bucket = this.getBucket(bucketKey || link.text.charAt(i));
				if (bucket && bucket.name) break;
			}
		}
		
		
		if (bucket && bucket.name) {
			bucket.addElement(link);
		} else {
//			alert('no bucket found');
		}
	},
	initialRender : function() {
		var container = this.container;
		var keys = this.getBucketKeys().sort();	
		
		for (var i = 0; i < keys.length; i++) {
			var bucket = this.getBucket(keys[i]);
			var renderedBucket = this.renderBucket(bucket);
			if (bucket && bucket.name && bucket.getElements().length > 0) {
				if (renderedBucket) {
					var links = bucket.getElements();
					if (links)
						links.sort(function(link1, link2){
							var one = link1.text.toLowerCase();
							var two = link2.text.toLowerCase();
							if (one < two) return -1;
							else if (one > two) return 1;
							else return 0;							
						})
					for (var x = 0; x < links.length; x++) {
						var renderedLink = this.renderLink(links[x]);
						if (renderedLink)
							bucket.container.appendChild(renderedLink);
					}
					var spacerDiv = document.createElement("DIV");
						Element.addClassName(spacerDiv, "spacerDiv"); 
					bucket.container.appendChild(spacerDiv);
					
					if (this.hasLinkToTop) {
						var linkToTop = document.createElement("A");
							linkToTop.href = "#top";
							linkToTop.innerHTML = "[ Back to Top ]";
							Element.addClassName(linkToTop, "backToTop");
						bucket.container.appendChild(linkToTop);
					}
					
					var spacerDiv = document.createElement("DIV");
						Element.addClassName(spacerDiv, "spacerDiv"); 
					bucket.container.appendChild(spacerDiv);
				}
			} else {
				Element.remove(bucket.container);
			}
		}
		this.initializeFromUrl();
	},
	renderBucket : function(bucket) {
		try {
			var div = $(bucket.name.toUpperCase());
			if (!div) {
				div = document.createElement("DIV");
				div.id = (bucket.key) ? bucket.key.toUpperCase() : bucket.name.toUpperCase();
				Element.addClassName(div, 'bucket');				
				var a = document.createElement("A");
					a.innerHTML = bucket.name;					
					a.href = "#top";
					Element.addClassName(a, 'alphabetheading');
				div.appendChild(a);
			}
			bucket.container = div;
			return div;
		} catch (e) {
			alert(e);
			return null;
		}
	},
	renderLink : function(link) {
		try {
			var div = document.createElement("DIV");
				link.container = div;
			var l = undefined;
			var url = (link.url || "").trim();
			if (url == "" || url == "#") {
				l = document.createElement("SPAN");
				l.appendChild(document.createTextNode(link.text.escapeHTML())); 
				Element.addClassName(l, 'flTitle');
			} else {
				l = document.createElement("A");
				l.href = link.url;
				l.innerHTML = link.text.escapeHTML();				
				Element.addClassName(l, 'flLink ');
			}
			div.appendChild(l);
			Element.addClassName(div, 'link-div');
			if (link.description && link.description.trim() != "") {
				var description = document.createElement("SPAN");
					description.appendChild(document.createTextNode(" - "));
					description.appendChild(document.createTextNode(link.description));
				Element.addClassName(description, 'articleTimeDate');

				div.appendChild(description);		
			}

			return div;
		} catch (e) {
			return null;
		}
	},
	registerPullDownManager : function(pmanager) {
		var pulldowns = pmanager.getPullDowns();
		this.pmanager = pmanager;
		for (var i = 0; i < pulldowns.length; i++) {
			var pulldown = pulldowns[i];
			if (pulldown) {
				Event.observe(pulldown, 'change', this.filter.bindAsEventListener(this));
			}	
		}
	},
	registerFilterDelegate : function(delegate) {
		if (delegate)
			this.filterDelegate = delegate;
	},
	filter : function(event) {
		var selections = {};
		var pulldowns = this.pmanager.getPullDowns();
		for (var i = 0; i < pulldowns.length; i++) {
			var pulldown = pulldowns[i];
			if (pulldown) {
				var index = pulldown.selectedIndex;
				var v = pulldown[index].value;
				if (this.hasShowAll && index ==0)
					v = UTIL.SHOW_ALL;
				selections[pulldown.name] = v;
			}
		}
		
		var keys = this.getBucketKeys().sort();
		var anyBucketShowing = false;
		for (var i = 0; i < keys.length; i++) {
			var bucket = this.getBucket(keys[i]);
			if (bucket && bucket.name && bucket.getElements().length > 0) {
				var links = bucket.getElements();
				var toShow = false;
				for (var x =0; x < links.length; x++) {
					var link = links[x];

					if (this.filterDelegate && this.filterDelegate(link, selections)) {
						link.container.style.display = "block";
						link.container.style.visibility = "visible";
						toShow = true;
					} else {
						link.container.style.display = "none";
						link.container.style.visibility = "hidden";
					}
					if (toShow) {
						bucket.container.style.display = "block";
						bucket.container.style.visibility = "visible";
						anyBucketShowing = true;
					} else {
						bucket.container.style.display = "none";
						bucket.container.style.visibility = "hidden";					
					}
				}
			}
		}
		var message = $('emptySelection');
		if (!anyBucketShowing) {
			message.style.display = "block";
			message.style.visibility = "visible";
		} else {
			message.style.display = "none";
			message.style.visibility = "hidden";					
		}
	},
	initializeFromUrl : function() {
	     var url = window.location.href;
	   	var qm = url.indexOf("?");
		if (qm < 0 || !this.pmanager || this.pmanager.getPullDowns().length <= 0) return;
		url = unescape(url.substr(qm + 1, url.length));
	    var pattern = /(\w+)?_(\w+)=([^&]+)/g;
        var result = null;
	    while ((result = pattern.exec(url)) != null) {
			switch (result[1]) {
				case "csv":
					(this.pmanager.getById(result[2]) || {}).value = result[3];
					break;
				case "csi":
					(this.pmanager.getById(result[2]) || {}).selectedIndex = result[3];
					break;
				case "v":
					this.pmanager.getPullDowns().each(function(pulldown){
						pulldown.value = result[3];
					});
					break;
				case "i":
					this.pmanager.getPullDowns().each(function(pulldown){
						pulldown.selectedIndex = result[3];
					});
					break;
				case "f":
					var index = parseInt(result[2]);
					var v = parseInt(result[3]);
					if (isNaN(v))
						this.pmanager.getPullDowns()[index].value = result[3];
					else						
						this.pmanager.getPullDowns()[index].selectedIndex = v;
					break;
				default:
					break;
			}
	    }
	}
}

Bucket = Class.create();
Bucket.prototype = {
	initialize : function(myName, myKey) {
		this.name = myName;
		this.key = myKey;
		this.elements = [];
	},
	addElement : function(element) {
		if (element) this.elements.push(element);
	},
	getElements : function() {
		return this.elements;
	}
}





