window.addOnload = function (fn) {
    if (!window.OnloadCache) window.OnloadCache = [];
    var ol = window.OnloadCache;
    ol.push( fn );
}
window.addOnSubmit = function (fn) {
	if (!window.OnsubmitCache) window.OnsubmitCache = [];
    var os = window.OnsubmitCache;
    os.push( fn );
}


var months = new Array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep', 'Oct','Nov','Dec');
			
			
function formatStringDate(date){
	var mm = date.substring(0,2);
	var dd = date.substring(3,5);
	var yy = date.substring(6,10);
	activeDate=new Date(yy,mm,dd);
	
	document.write(dd + " " + months[mm-1] + " " + (yy) );
}

function DisplayArticles (X) {
	var ok=0;
 	var articles="";
	for(var x=0; x <document.forms.length; x++){		
		var Y = document.forms[x];
		if (Y.article_list) {
			for (var i=0; i<Y.article_list.length; i++) { 
				if (Y.article_list[i].checked == true) {
					ok=1;
				   	articles+="&article_list=" + Y.article_list[i].value;
				} 
			}
		}
	}
	if (ok) {
		window.location.href="/gsweb/gsc/news-info/external/print?1=1" + articles;
	} else alert("Please use the checkboxes to select one or more stories to display");
}

function showTime(date , type) {

	var time;	
	// showTime available types.....
	// "c" - civilian time eg. 4:30 PM
	// "m" - military time eg. 1400 hours
	var xhour = date.getHours();
	var xminute = date.getMinutes();
	if (xminute < 10) xminute = "0" + xminute;
 	switch (type) {
    	case "c":
			var ampm = "AM";
			if (date.getHours() >= 12) {
				ampm = "PM";
				if (date.getHours() != 12) xhour = date.getHours() - 12;
			}
			if (date.getHours()==0) xhour = 12;
			time = xhour + ":"+ xminute + " " + ampm;
      		break;
		case "m":
			if (xhour < 10) xhour = "0" + xhour;
			time = xhour + "" + xminute + " hours ";
			break;
	}
 	document.write(" " + time);
}

function formatDate(date){

	if (date.length) formatStringDate(date);
	else{

		document.write(
			date.getDate() + 
			" " + 
			months[date.getMonth()] + 
			" " + 
			date.getFullYear());
	}
}

function gsrIntercept() 
{
	// can be intercepted to put in some custom additions to what is 
	// passed into /gsr
}

function openWindow(url,width,height){
winName = "popUp";
features = "width="+width+",height="+height+",resizable=no,scrollbars=no";
window.open(url,winName,features);
}

