// Create the namespace objects if nec.
var com;
if (com == undefined) { com = new Object(); }
if (com.gs == undefined) { com.gs = new Object(); }
if (com.gs.fig == undefined) { com.gs.fig = new Object(); }
if (com.gs.fig.foldingPanels == undefined) { com.gs.fig.foldingPanels = new Object(); }

com.gs.fig.foldingPanels.FoldControlImageCache = new Array();
com.gs.fig.foldingPanels.collapsibleSubPanelsCache = new Array();

com.gs.fig.foldingPanels.PANELS_FOLDED_DEFAULT_VAL = true;

com.gs.fig.foldingPanels.initImageCache = function() {
   // Initialize the image cache
   com.gs.fig.foldingPanels.FoldControlImageCache["COLLAPSE_BUTTON"] = absolutePath + "/images/folding-panels-collapse.gif";
   com.gs.fig.foldingPanels.FoldControlImageCache["EXPAND_BUTTON"] = absolutePath + "/images/folding-panels-expand.gif";
   var preload = new Image();
   for (var i = 0; i < com.gs.fig.foldingPanels.FoldControlImageCache.length; i++) {
      preload.src = com.gs.fig.foldingPanels.FoldControlImageCache[i];
   }
}

com.gs.fig.foldingPanels.registerPanels = function() {
   // Now search the DOM for all divs with class="collapsibleSubPanel" and
   // create and register new panel objects for them.
   var divs = document.getElementsByTagName("div");
   var numDivs = divs.length;
   for (var i = 0; i < numDivs; i++) {
      var div = divs[i];
      if (div.className == "collapsibleSubPanel") {
         com.gs.fig.foldingPanels.collapsibleSubPanelsCache.push(new com.gs.fig.foldingPanels.Panel(div));
      }
   }
}

com.gs.fig.foldingPanels.init = function() {
   com.gs.fig.foldingPanels.initImageCache();
   com.gs.fig.foldingPanels.registerPanels();
}

/**
 * The folding panel object constructor
 */
com.gs.fig.foldingPanels.Panel = function(panelDIV, folded) {
   if (panelDIV != undefined) {
   
      // ====================================================================
      // "Constants"
      // ====================================================================
   
      this.MOUSE_OVER_CURSOR = "hand";
      this.MOUSE_OUT_CURSOR = "pointer";
      
      // ====================================================================
      // Methods
      // ====================================================================
   
      this.handleMouseOver = function() {
         this.controlIMG.style.cursor = this.MOUSE_OVER_CURSOR;
      }
      
      this.handleMouseOut = function() {
         this.controlIMG.style.cursor = this.MOUSE_OUT_CURSOR;
      }
      
      this.handleClick = function() {
         this.setFolded(!this.isFolded);
      }
      
      this.setFolded = function(folded) {
         if (folded) {
            this.bodyDIV.style.visibility = "hidden";
            this.bodyDIV.style.display = "none";
            this.controlIMG.src = this.imageCache["COLLAPSE_BUTTON"];
            this.isFolded = true;
         } else {
            this.bodyDIV.style.visibility = "visible";
            this.bodyDIV.style.display = "block";
            this.controlIMG.src = this.imageCache["EXPAND_BUTTON"];
            this.isFolded = false;
         }
      }
      
      // ====================================================================
      // Properties
      // ====================================================================

      // We store a local reference to the FoldControlImageCache
      this.imageCache = com.gs.fig.foldingPanels.FoldControlImageCache;
      
      this.panelDIV = panelDIV;
      this.headerDIV = undefined;
      this.controlIMG = undefined;
      this.bodyDIV = undefined;

      // folded can be undefined. If it is, use the default value
      this.isFolded = (folded != undefined) ? folded : com.gs.fig.foldingPanels.PANELS_FOLDED_DEFAULT_VAL;
      
      // ====================================================================
      // Initialization
      // ====================================================================

      // We need references to the various HTML elements that make up the control.
      // So walk the DOM to find them. Constraints are:
      // 1. The header has to be a DIV
      // 2. The body has to be a DIV
      // 3. The collapse control has to be an IMG
      
      var divs = this.panelDIV.getElementsByTagName("div");
      for (var i = 0; i < divs.length; i++) {
         var node = divs[i];
   
         if (node.className == "body") {
            this.bodyDIV = node;
         } else if (node.className == "header") {
            this.headerDIV = node;
         }
         if (this.bodyDIV && this.headerDIV)
         	break;
      }
      
      var imgs = this.panelDIV.getElementsByTagName("img");
      for (var i = 0; i < imgs.length; i++) {
         var node = imgs[i];
         
         if (node.className == "foldControl") {
            this.controlIMG = node;
            break;
         }
      }
      
      // Once we've found all the HTML elements, we need to instrument the control so it'll work
      // and set the initial state (folded or not) based on the value passed into the constructor
      
      if (this.headerDIV != undefined && this.controlIMG != undefined && this.bodyDIV != undefined) {
         this.setFolded(this.isFolded);
         this.controlIMG.style.cursor = this.MOUSE_OUT_CURSOR;
         
         // add a properties to the HTML elements that point to this object
         this.panelDIV.panelObj = this;
         this.headerDIV.panelObj = this;
         this.controlIMG.panelObj = this;
         this.bodyDIV.panelObj = this;
         
         // now add the various event handlers.
         this.controlIMG.onmouseover = function() {
            this.panelObj.handleMouseOver();
         }
         
         this.controlIMG.onmouseout = function() {
            this.panelObj.handleMouseOut();
         }
         
         this.controlIMG.onclick = function() {
            this.panelObj.handleClick();
         }
      } else {
         alert("Unable to initialize folding panel!");
      }
   }
}
