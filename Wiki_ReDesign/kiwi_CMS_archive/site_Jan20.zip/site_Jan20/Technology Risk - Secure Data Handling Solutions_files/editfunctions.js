function editDotWithOrigin(atag, nodeId)
{
		atag.href = atag.href + "&se=" + escape(window.location.pathname) + escape(window.location.search);
}

function kiwi_sel( id, scolor, bcorners )
{
    imghome = '/elm-assets/images/edit-dots';
    
    //if ( scolor != '' )
        //scolor = '_' + scolor;
    //alert(scolor);
    if ( bcorners )
    {
        //turn on animated corners
    	imgid = 'nw' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/nw_selection' + scolor + '.gif';
    	imgid = 'ne' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/ne_selection' + scolor + '.gif';
    	imgid = 'sw' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/sw_selection' + scolor + '.gif';
    	imgid = 'se' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/se_selection' + scolor + '.gif';

    	//turn on north and south handles
    	imgid = 'n' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/north_selection' + scolor + '.gif';
    	imgid = 's' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/south_selection' + scolor + '.gif';
    }
    else
    {
        //turn off animated corners
    	imgid = 'nw' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/corner_blank.gif';
    	imgid = 'ne' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/corner_blank.gif';
    	imgid = 'sw' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/corner_blank.gif';
    	imgid = 'se' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/corner_blank.gif';
	
    	//turn off north and south handles
    	imgid = 'n' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/pole_blank' + scolor + '.gif';
    	imgid = 's' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/pole_blank' + scolor + '.gif';
    }	
}

function kiwi_sel_folder( id, scolor, bcorners )
{
    imghome = '/elm-assets/images/edit-dots';
    
    //if ( scolor != '' )
        //scolor = '_' + scolor;
    //alert(scolor);
    if ( bcorners )
    {
        //turn on animated corners
    	imgid = 'nw' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/nw_selection' + scolor + '.gif';
    	imgid = 'ne' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/ne_selection' + scolor + '.gif';
    	imgid = 'sw' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/sw_selection' + scolor + '.gif';
    	imgid = 'se' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/se_selection' + scolor + '.gif';

    	//turn on north and south handles
    	imgid = 'n' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/folder_view_selection' + scolor + '.gif';
    	imgid = 'na' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/folder_add_selection' + scolor + '.gif';
    	imgid = 's' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/folder_view_selection' + scolor + '.gif';
    	imgid = 'sa' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/folder_add_selection' + scolor + '.gif';

    }
    
    else
    {
        //turn off animated corners
    	imgid = 'nw' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/corner_blank.gif';
    	imgid = 'ne' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/corner_blank.gif';
    	imgid = 'sw' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/corner_blank.gif';
    	imgid = 'se' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/corner_blank.gif';
	
    	//turn off north and south handles
    	imgid = 'n' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/folder_view' + scolor + '.gif';
    	imgid = 'na' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/folder_add' + scolor + '.gif';
    	imgid = 's' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/folder_view' + scolor + '.gif';
    	imgid = 'sa' + id;
    	img = document.images[imgid];
    	img.src = imghome + '/folder_add' + scolor + '.gif';
    }	
}
